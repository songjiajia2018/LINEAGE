## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
    message = FALSE,
    error = FALSE,
    warning = FALSE,
    collapse = TRUE,
    fig.align = "center"
)

## ----option1, eval=FALSE------------------------------------------------------
#  if(!requireNamespace("BiocManager", quietly = TRUE))
#      install.packages("BiocManager")
#  BiocManager::install("LINEAGE")

## ----option2, eval=FALSE------------------------------------------------------
#  # install.packages("devtools")
#  devtools::install_github("songjiajia2018/LINEAGE")

## ----option3, eval=FALSE------------------------------------------------------
#  install.packages("the_directory_that_contain_the_package/LINEAGE_0.99.1.tar.gz",repos=NULL,type="source")

## ----LINEAGE------------------------------------------------------------------
library(LINEAGE)

## ----mode1, eval=FALSE--------------------------------------------------------
#  data("TF1_clones")
#  data=TF1_clones$data
#  result=lineage(data = data, repeats = 30, thread = 20)

## ----mode2--------------------------------------------------------------------
data("TF1_clones")
data=TF1_clones$data
result=lineage(data = data, repeats = 30, thread = NULL)

## ----lineage_tree-------------------------------------------------------------
# The inferred clone labels are embedded in the returned result
# as result$label. We also provide lineage_tree function to trace # the lineage tree of the returned result.
hc=lineage_tree(result)
str(hc, max.level = 1)

## ----plots--------------------------------------------------------------------
label=TF1_clones$rlabel    #reference clone labels

plots0=traceplot(result, label)  #plots with reference clone labels
plots=traceplot(result, result$label)  #plots with inferred clone labels

## ----plots_output, eval=FALSE-------------------------------------------------
#  # 2d visualization cluster results with clonal labels
#  # colored in reference clone labels
#  print(plots0$d2d)
#  # or inferred labels
#  print(plots$d2d)
#  # Heatmap results with markers information across cells and color bar is
#  # colored in reference clone labels
#  print(plots$heatmap)

## ----result-------------------------------------------------------------------
# The recommended result is embedded in the returned result as result$best.
best=list(result=result$best, plots=plots)
str(best, max.level=1)
str(best$result, max.level=1)

## -----------------------------------------------------------------------------
sessionInfo()


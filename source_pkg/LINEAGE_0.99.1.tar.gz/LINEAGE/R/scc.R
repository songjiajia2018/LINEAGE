#' scc example
#' @name scc
#' 
#' @description The consensus clustering result.
#' 
#' @format An object of class \code{"numeric"}
#' 
#' @source This dataset was generated during lineage analysis by LINEAGE.
#' 
#' @docType data
#' 
#' @usage data("scc")
#' 
NULL
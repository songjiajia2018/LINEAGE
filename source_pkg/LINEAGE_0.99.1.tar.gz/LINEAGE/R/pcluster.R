#' pcluster example
#' @name pcluster
#' 
#' @description A list containing clustering results in selected subspaces with kmeans.
#' 
#' @format An object of class \code{"list"}
#' 
#' @source This dataset was generated during lineage analysis by LINEAGE.
#'
#' @docType data
#' 
#' @usage data("pcluster")
#' 
NULL
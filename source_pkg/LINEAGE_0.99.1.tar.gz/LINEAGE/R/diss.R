#' diss example
#' @name diss
#' 
#' @description A list containing Euclidean distance matrixes of selected subspaces.
#' 
#' @format An object of class \code{"list"}
#' 
#' @source This dataset was generated during lineage analysis by LINEAGE.
#' 
#' @docType data
#' 
#' @usage data("diss")
#' 
NULL
#' cs example
#' @name cs
#' 
#' @description Indexes of selected subspaces.
#' 
#' @format An object of class \code{"numeric"}
#' 
#' @source This dataset was generated during lineage analysis by LINEAGE.
#' 
#' @docType data
#' 
#' @usage data("cs")
#' 
NULL